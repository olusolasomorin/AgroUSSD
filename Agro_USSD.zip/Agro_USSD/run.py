from src.main import main_menu

if __name__ == "_main_":
    main_menu()

