from src.models.farmer import Farmer
from src.models.buyer import Buyer
from src.utils.data_handler import load_users, save_users

def register_Farmer(name, phone, location, pin):
    users = load_users()

    # Check if phone already exists
    for user in users:
        if user["phone"] == phone:
            return "Phone number already registered."

    farmer = Farmer(name, phone, location, pin)
    users.append(farmer.to_dict())
    save_users(users)
    return f"Farmer {name} registered successfully!"

def login_Farmer(phone, pin):
    users = load_users()
    for user in users:
        if user["phone"] == phone and user["pin"] == pin:
            return f"Welcome back, {user['name']}!"
    return "Invalid phone or PIN. Try again."


def register_Buyer(name, phone, location, pin):
    users = load_users()

    # Check if phone already exists
    for user in users:
        if user["phone"] == phone:
            return "Phone number already registered."

    buyer = Buyer(name, phone, location, pin)
    users.append(buyer.to_dict())
    save_users(users)
    return f"Buyer {name} registered successfully!"

def login_Buyer(phone, pin):
    users = load_users()
    for user in users:
        if user["phone"] == phone and user["pin"] == pin:
            return f"Welcome back, {user['name']}!"
    return "Invalid phone or PIN. Try again."
