from src.services.user_service import register_Farmer, login_Farmer, register_Buyer, login_Buyer


def main_menu():
    while True:
        print("\n--- AgroUSSD ---")
        print("1. Register Farmer")
        print("2. Login Farmer")
        print("3. Register Buyer")
        print("4. Login Buyer")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            name = input("Enter your name: ")
            phone = input("Enter your phone: ")
            location = input("Enter your location: ")
            pin = input("Choose a PIN: ")
            print(register_Farmer(name, phone, location, pin))

        elif choice == "2":
            phone = input("Enter phone: ")
            pin = input("Enter PIN: ")
            print(login_Farmer(phone, pin))
        
        elif choice == "3":
            name = input("Enter your name: ")
            phone = input("Enter your phone: ")
            location = input("Enter your location: ")
            pin = input("Choose a PIN: ")
            print(register_Buyer(name, phone, location, pin))

        elif choice == "4":
            phone = input("Enter phone: ")
            pin = input("Enter PIN: ")
            print(login_Buyer(phone, pin))

        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid choice, try again.")
