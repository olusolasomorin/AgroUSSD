class Buyer:
    def _init_(self, name, phone, location, pin):
        self.name = name
        self.phone = phone
        self.location = location
        self.pin = pin

    def to_dict(self):
        """Convert farmer to dictionary for saving to JSON"""
        return {
            "name": self.name,
            "phone": self.phone,
            "location": self.location,
            "pin": self.pin
        }

